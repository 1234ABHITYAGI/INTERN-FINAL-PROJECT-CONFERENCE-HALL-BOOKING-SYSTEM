using Microsoft.AspNetCore.Mvc;
using ConferenceRoomBooking.Data;
using Microsoft.EntityFrameworkCore;

namespace ConferenceRoomBooking.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _context;

        public HomeController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null)
            {
                return RedirectToAction("Login", "Account");
            }

            // Get user's recent bookings
            var recentBookings = _context.Bookings
                .Include(b => b.Room)
                .Where(b => b.UserId == userId.Value)
                .OrderByDescending(b => b.CreatedAt)
                .Take(5)
                .ToList();

            // Get available rooms
            var availableRooms = _context.ConferenceRooms
                .Where(r => r.IsActive)
                .ToList();

            // Get today's bookings for the user
            var todayBookings = _context.Bookings
                .Include(b => b.Room)
                .Where(b => b.UserId == userId.Value && b.StartTime.Date == DateTime.Today)
                .OrderBy(b => b.StartTime)
                .ToList();

            ViewBag.RecentBookings = recentBookings;
            ViewBag.AvailableRooms = availableRooms;
            ViewBag.TodayBookings = todayBookings;

            return View();
        }
    }
}
