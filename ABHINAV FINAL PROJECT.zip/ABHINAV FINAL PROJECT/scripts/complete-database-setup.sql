-- COMPLETE DATABASE SETUP FOR CONFERENCE ROOM BOOKING SYSTEM
-- Run this script to set up everything at once

USE master;
GO

-- Step 1: Create Database
IF EXISTS (SELECT name FROM sys.databases WHERE name = 'ConferenceRoomBookingDb')
BEGIN
    ALTER DATABASE ConferenceRoomBookingDb SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE ConferenceRoomBookingDb;
END
GO

CREATE DATABASE ConferenceRoomBookingDb;
GO

USE ConferenceRoomBookingDb;
GO

-- Step 2: Create Tables
CREATE TABLE Users (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL,
    Email NVARCHAR(255) NOT NULL UNIQUE,
    Username NVARCHAR(50) NOT NULL UNIQUE,
    Password NVARCHAR(255) NOT NULL,
    IsAdmin BIT NOT NULL DEFAULT 0,
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedAt DATETIME2 NOT NULL DEFAULT GETDATE(),
    LastLoginAt DATETIME2 NULL
);

CREATE TABLE ConferenceRooms (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL,
    Description NVARCHAR(500) NULL,
    Location NVARCHAR(200) NULL,
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedAt DATETIME2 NOT NULL DEFAULT GETDATE()
);

CREATE TABLE Bookings (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    UserId INT NOT NULL,
    ConferenceRoomId INT NOT NULL,
    Title NVARCHAR(200) NOT NULL,
    Description NVARCHAR(1000) NULL,
    StartTime DATETIME2 NOT NULL,
    EndTime DATETIME2 NOT NULL,
    Status NVARCHAR(20) NOT NULL DEFAULT 'Confirmed',
    CreatedAt DATETIME2 NOT NULL DEFAULT GETDATE(),
    CancelledAt DATETIME2 NULL,
    
    CONSTRAINT FK_Bookings_Users FOREIGN KEY (UserId) REFERENCES Users(Id),
    CONSTRAINT FK_Bookings_ConferenceRooms FOREIGN KEY (ConferenceRoomId) REFERENCES ConferenceRooms(Id)
);

-- Step 3: Create Indexes
CREATE INDEX IX_Users_Username ON Users(Username);
CREATE INDEX IX_Users_Email ON Users(Email);
CREATE INDEX IX_Bookings_UserId ON Bookings(UserId);
CREATE INDEX IX_Bookings_ConferenceRoomId ON Bookings(ConferenceRoomId);
CREATE INDEX IX_Bookings_StartTime ON Bookings(StartTime);

-- Step 4: Insert Users
INSERT INTO Users (Name, Email, Username, Password, IsAdmin) VALUES
('Abhinav Tyagi', 'abhinav.tyagi@company.com', 'abhinav', 'admin123', 1),
('Rajesh Kumar', 'rajesh.kumar@company.com', 'rajesh', 'admin123', 0),
('Rohit Gupta', 'rohit.gupta@company.com', 'rohit', 'user123', 0),
('Priya Singh', 'priya.singh@company.com', 'priya', 'user123', 0),
('Vikram Patel', 'vikram.patel@company.com', 'vikram', 'user123', 0),
('Anita Verma', 'anita.verma@company.com', 'anita', 'user123', 0);

-- Step 5: Insert Conference Rooms (WITHOUT CAPACITY)
INSERT INTO ConferenceRooms (Name, Description, Location) VALUES
('Board Room', 'Executive meeting room with video conferencing facilities', 'Floor 10, East Wing'),
('Conference Room A', 'Large conference room with presentation equipment', 'Floor 5, West Wing'),
('Conference Room B', 'Medium conference room with whiteboard', 'Floor 5, East Wing'),
('Meeting Room 1', 'Small meeting room for team discussions', 'Floor 3, North Wing'),
('Meeting Room 2', 'Small meeting room with phone conference', 'Floor 3, South Wing'),
('Training Room', 'Large training room with projector and sound system', 'Floor 2, Central');

-- Step 6: Insert Sample Bookings
DECLARE @Tomorrow DATETIME2 = DATEADD(DAY, 1, CAST(GETDATE() AS DATE));

INSERT INTO Bookings (UserId, ConferenceRoomId, Title, Description, StartTime, EndTime, Status) VALUES
(2, 1, 'Team Meeting', 'Weekly team sync', DATEADD(HOUR, 9, @Tomorrow), DATEADD(HOUR, 10, @Tomorrow), 'Confirmed'),
(3, 2, 'Client Presentation', 'Product demo', DATEADD(HOUR, 14, @Tomorrow), DATEADD(HOUR, 16, @Tomorrow), 'Confirmed'),
(4, 3, 'Project Planning', 'Sprint planning', DATEADD(HOUR, 11, @Tomorrow), DATEADD(HOUR, 12, @Tomorrow), 'Confirmed');

PRINT '✅ DATABASE SETUP COMPLETE!';
PRINT '';
PRINT 'LOGIN CREDENTIALS:';
PRINT 'Admin: abhinav / admin123';
PRINT 'Users: rajesh, rohit, priya / user123';
PRINT '';
PRINT 'CONFERENCE ROOMS: 6 rooms created (no capacity field)';
PRINT 'SAMPLE BOOKINGS: 3 bookings created';
