using Microsoft.AspNetCore.Mvc;
using ConferenceRoomBooking.Data;
using ConferenceRoomBooking.Services;

namespace ConferenceRoomBooking.Controllers
{
    public class AdminAccessController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IAdminAccessService _adminAccessService;

        public AdminAccessController(ApplicationDbContext context, IAdminAccessService adminAccessService)
        {
            _context = context;
            _adminAccessService = adminAccessService;
        }

        [HttpGet]
        public IActionResult Authenticate()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Authenticate(string accessCode)
        {
            if (string.IsNullOrEmpty(accessCode))
            {
                ViewBag.Error = "Access code is required.";
                return View();
            }

            var isValid = await _adminAccessService.ValidateAccessCodeAsync(accessCode);
            if (!isValid)
            {
                ViewBag.Error = "Invalid or expired access code.";
                return View();
            }

            // Set admin access session
            HttpContext.Session.SetString("AdminAccess", "true");
            return RedirectToAction("Index", "Admin");
        }

        [HttpGet]
        public IActionResult ChangePassword()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> ChangePassword(string currentCode, string newCode)
        {
            if (string.IsNullOrEmpty(currentCode) || string.IsNullOrEmpty(newCode))
            {
                ViewBag.Error = "Both current and new access codes are required.";
                return View();
            }

            var success = await _adminAccessService.ChangeAccessCodeAsync(currentCode, newCode);
            if (!success)
            {
                ViewBag.Error = "Invalid current access code.";
                return View();
            }

            ViewBag.Success = "Access code changed successfully.";
            return View();
        }

        public IActionResult LockedOut()
        {
            return View();
        }
    }
}
