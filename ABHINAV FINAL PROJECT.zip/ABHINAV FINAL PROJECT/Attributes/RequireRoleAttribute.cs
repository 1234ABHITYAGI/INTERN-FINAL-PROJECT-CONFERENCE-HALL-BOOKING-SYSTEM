using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace ConferenceRoomBooking.Attributes
{
    public class RequireRoleAttribute : Attribute, IAuthorizationFilter
    {
        private readonly string _role;

        public RequireRoleAttribute(string role)
        {
            _role = role;
        }

        public void OnAuthorization(AuthorizationFilterContext context)
        {
            var userRole = context.HttpContext.Session.GetString("UserRole");

            if (string.IsNullOrEmpty(userRole) || userRole != _role)
            {
                if (string.IsNullOrEmpty(userRole))
                {
                    context.Result = new RedirectToActionResult("Login", "Account", null);
                }
                else
                {
                    context.Result = new ViewResult
                    {
                        ViewName = "AccessDenied"
                    };
                }
            }
        }
    }
}
