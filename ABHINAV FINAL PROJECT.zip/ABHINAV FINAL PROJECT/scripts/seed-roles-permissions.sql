-- Seed Roles and Permissions for Conference Room Booking System
USE TestIPI;
GO

-- Insert Roles
INSERT INTO Roles (Name, Description, IsActive, CreatedAt) VALUES
('Super Admin', 'Full system access with all permissions', 1, GETDATE()),
('Admin', 'Administrative access to manage bookings and users', 1, GETDATE()),
('Manager', 'Manager level access to view reports and manage team bookings', 1, GETDATE()),
('User', 'Standard user with booking capabilities', 1, GETDATE()),
('Guest', 'Limited access for viewing only', 1, GETDATE());
GO

-- Insert Permissions
INSERT INTO Permissions (Name, Code, Description, Category, IsActive, CreatedAt) VALUES
-- Booking Permissions
('View All Bookings', 'VIEW_ALL_BOOKINGS', 'Can view all bookings in the system', 'Booking', 1, GETDATE()),
('Create Booking', 'CREATE_BOOKING', 'Can create new bookings', 'Booking', 1, GETDATE()),
('Edit Own Booking', 'EDIT_OWN_BOOKING', 'Can edit own bookings', 'Booking', 1, GETDATE()),
('Edit Any Booking', 'EDIT_ANY_BOOKING', 'Can edit any booking in the system', 'Booking', 1, GETDATE()),
('Cancel Own Booking', 'CANCEL_OWN_BOOKING', 'Can cancel own bookings', 'Booking', 1, GETDATE()),
('Cancel Any Booking', 'CANCEL_ANY_BOOKING', 'Can cancel any booking in the system', 'Booking', 1, GETDATE()),
('Delete Any Booking', 'DELETE_ANY_BOOKING', 'Can permanently delete any booking', 'Booking', 1, GETDATE()),
('Book On Behalf', 'BOOK_ON_BEHALF', 'Can create bookings on behalf of other users', 'Booking', 1, GETDATE()),

-- Room Permissions
('View Rooms', 'VIEW_ROOMS', 'Can view conference rooms', 'Room', 1, GETDATE()),
('Manage Rooms', 'MANAGE_ROOMS', 'Can manage conference rooms', 'Room', 1, GETDATE()),
('Create Room', 'CREATE_ROOM', 'Can create new conference rooms', 'Room', 1, GETDATE()),
('Edit Room', 'EDIT_ROOM', 'Can edit conference room details', 'Room', 1, GETDATE()),
('Delete Room', 'DELETE_ROOM', 'Can delete conference rooms', 'Room', 1, GETDATE()),

-- User Management Permissions
('View Users', 'VIEW_USERS', 'Can view user list', 'User', 1, GETDATE()),
('Manage Users', 'MANAGE_USERS', 'Can manage user accounts', 'User', 1, GETDATE()),
('Create User', 'CREATE_USER', 'Can create new user accounts', 'User', 1, GETDATE()),
('Edit User', 'EDIT_USER', 'Can edit user account details', 'User', 1, GETDATE()),
('Delete User', 'DELETE_USER', 'Can delete user accounts', 'User', 1, GETDATE()),
('Assign Roles', 'ASSIGN_ROLES', 'Can assign roles to users', 'User', 1, GETDATE()),

-- System Permissions
('Access Admin Panel', 'ACCESS_ADMIN_PANEL', 'Can access administrative panel', 'System', 1, GETDATE()),
('View Reports', 'VIEW_REPORTS', 'Can view system reports', 'System', 1, GETDATE()),
('Manage System Settings', 'MANAGE_SYSTEM_SETTINGS', 'Can manage system settings', 'System', 1, GETDATE()),
('View Audit Logs', 'VIEW_AUDIT_LOGS', 'Can view system audit logs', 'System', 1, GETDATE());
GO

-- Assign Permissions to Roles

-- Super Admin gets ALL permissions
INSERT INTO RolePermissions (RoleId, PermissionId, GrantedAt, IsActive)
SELECT r.Id, p.Id, GETDATE(), 1
FROM Roles r
CROSS JOIN Permissions p
WHERE r.Name = 'Super Admin' AND p.IsActive = 1;

-- Admin gets most permissions except system management
INSERT INTO RolePermissions (RoleId, PermissionId, GrantedAt, IsActive)
SELECT r.Id, p.Id, GETDATE(), 1
FROM Roles r
CROSS JOIN Permissions p
WHERE r.Name = 'Admin' 
  AND p.IsActive = 1
  AND p.Code IN (
    'VIEW_ALL_BOOKINGS', 'CREATE_BOOKING', 'EDIT_OWN_BOOKING', 'EDIT_ANY_BOOKING',
    'CANCEL_OWN_BOOKING', 'CANCEL_ANY_BOOKING', 'DELETE_ANY_BOOKING', 'BOOK_ON_BEHALF',
    'VIEW_ROOMS', 'MANAGE_ROOMS', 'CREATE_ROOM', 'EDIT_ROOM', 'DELETE_ROOM',
    'VIEW_USERS', 'MANAGE_USERS', 'CREATE_USER', 'EDIT_USER', 'ASSIGN_ROLES',
    'ACCESS_ADMIN_PANEL', 'VIEW_REPORTS'
  );

-- Manager gets booking and room management permissions
INSERT INTO RolePermissions (RoleId, PermissionId, GrantedAt, IsActive)
SELECT r.Id, p.Id, GETDATE(), 1
FROM Roles r
CROSS JOIN Permissions p
WHERE r.Name = 'Manager' 
  AND p.IsActive = 1
  AND p.Code IN (
    'VIEW_ALL_BOOKINGS', 'CREATE_BOOKING', 'EDIT_OWN_BOOKING', 'CANCEL_OWN_BOOKING',
    'CANCEL_ANY_BOOKING', 'BOOK_ON_BEHALF', 'VIEW_ROOMS', 'VIEW_USERS', 'VIEW_REPORTS'
  );

-- User gets basic permissions
INSERT INTO RolePermissions (RoleId, PermissionId, GrantedAt, IsActive)
SELECT r.Id, p.Id, GETDATE(), 1
FROM Roles r
CROSS JOIN Permissions p
WHERE r.Name = 'User' 
  AND p.IsActive = 1
  AND p.Code IN (
    'CREATE_BOOKING', 'EDIT_OWN_BOOKING', 'CANCEL_OWN_BOOKING', 'VIEW_ROOMS'
  );

-- Guest gets minimal permissions
INSERT INTO RolePermissions (RoleId, PermissionId, GrantedAt, IsActive)
SELECT r.Id, p.Id, GETDATE(), 1
FROM Roles r
CROSS JOIN Permissions p
WHERE r.Name = 'Guest' 
  AND p.IsActive = 1
  AND p.Code IN ('VIEW_ROOMS');

-- Assign roles to existing users
-- Make first user Super Admin
INSERT INTO UserRoles (UserId, RoleId, AssignedAt, IsActive)
SELECT 1, r.Id, GETDATE(), 1
FROM Roles r
WHERE r.Name = 'Super Admin';

-- Make second user Admin
INSERT INTO UserRoles (UserId, RoleId, AssignedAt, IsActive)
SELECT 2, r.Id, GETDATE(), 1
FROM Roles r
WHERE r.Name = 'Admin';

-- Make other users regular Users
INSERT INTO UserRoles (UserId, RoleId, AssignedAt, IsActive)
SELECT u.Id, r.Id, GETDATE(), 1
FROM Users u
CROSS JOIN Roles r
WHERE u.Id > 2 AND r.Name = 'User';

PRINT 'Roles and permissions seeded successfully!';
GO

-- Verification queries
SELECT 'Roles Created' as Info, COUNT(*) as Count FROM Roles WHERE IsActive = 1;
SELECT 'Permissions Created' as Info, COUNT(*) as Count FROM Permissions WHERE IsActive = 1;
SELECT 'Role Permissions Assigned' as Info, COUNT(*) as Count FROM RolePermissions WHERE IsActive = 1;
SELECT 'User Roles Assigned' as Info, COUNT(*) as Count FROM UserRoles WHERE IsActive = 1;

-- Show role assignments
SELECT 
    u.Name as UserName,
    r.Name as RoleName,
    ur.AssignedAt
FROM Users u
JOIN UserRoles ur ON u.Id = ur.UserId
JOIN Roles r ON ur.RoleId = r.Id
WHERE ur.IsActive = 1
ORDER BY u.Name, r.Name;
