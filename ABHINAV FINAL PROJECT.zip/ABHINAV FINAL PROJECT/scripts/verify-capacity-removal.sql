-- Verify that capacity column has been removed
USE TestIPI;
GO

PRINT '=== CAPACITY REMOVAL VERIFICATION ===';
PRINT '';

-- Check table structure
PRINT '1. CURRENT TABLE STRUCTURE:';
SELECT 
    '   Column: ' + COLUMN_NAME + ' (' + DATA_TYPE + ')' as ColumnInfo
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_NAME = 'ConferenceRooms'
ORDER BY ORDINAL_POSITION;

PRINT '';

-- Verify capacity column is gone
IF NOT EXISTS (
    SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_NAME = 'ConferenceRooms' AND COLUMN_NAME = 'Capacity'
)
BEGIN
    PRINT '2. CAPACITY COLUMN STATUS: ✅ SUCCESSFULLY REMOVED';
END
ELSE
BEGIN
    PRINT '2. CAPACITY COLUMN STATUS: ❌ STILL EXISTS';
END

PRINT '';

-- Show current room data
PRINT '3. CURRENT CONFERENCE ROOMS:';
SELECT 
    '   ' + Name + ' - ' + ISNULL(Location, 'No location') as RoomInfo
FROM ConferenceRooms
WHERE IsActive = 1
ORDER BY Name;

PRINT '';
PRINT '✅ CAPACITY FIELD SUCCESSFULLY REMOVED FROM ALL CONFERENCE ROOMS!';
PRINT '';
PRINT 'Updated Features:';
PRINT '   - Room selection shows: Name - Location';
PRINT '   - No capacity restrictions';
PRINT '   - Simplified room management';
PRINT '   - Cleaner user interface';
