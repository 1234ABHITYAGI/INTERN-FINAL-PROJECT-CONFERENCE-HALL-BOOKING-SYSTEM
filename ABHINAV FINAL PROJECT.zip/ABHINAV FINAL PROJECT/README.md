# Conference Room Booking System

A comprehensive ASP.NET Core 6.0 application for managing conference room bookings with role-based access control.

## Features

- **User Authentication & Authorization**
  - Role-based access control (Admin/User)
  - Secure login system
  - Password management

- **Room Management**
  - Create, edit, and delete conference rooms
  - Room availability tracking
  - Admin-only room management

- **Booking System**
  - Book conference rooms
  - View booking calendar
  - Manage existing bookings
  - Conflict prevention

- **Admin Features**
  - User management
  - Room management
  - System administration
  - Database testing tools

## Technology Stack

- **Backend**: ASP.NET Core 6.0
- **Database**: SQL Server
- **Frontend**: Razor Views with Bootstrap
- **Authentication**: Custom authentication system
- **ORM**: Entity Framework Core

## Prerequisites

- Visual Studio 2022 or later
- .NET 6.0 SDK
- SQL Server (LocalDB, Express, or Full)
- SQL Server Management Studio (recommended)

## Quick Setup

1. **Database Setup**
   - Open SQL Server Management Studio
   - Connect to your SQL Server instance
   - Run the database scripts in order from `/scripts/` folder

2. **Configure Connection String**
   - Update `appsettings.json` with your SQL Server connection string

3. **Run the Application**
   - Open the project in Visual Studio
   - Build the solution (Ctrl+Shift+B)
   - Run the application (F5)
   - Navigate to `https://localhost:5001`

## Default Login Credentials

### Admin Account
- **Username**: abhinav
- **Password**: admin123

### User Accounts
- **Username**: rajesh, priya, rohit, anita
- **Password**: user123

## Project Structure

\`\`\`
ConferenceRoomBooking/
├── Controllers/          # MVC Controllers
├── Models/              # Data models and ViewModels
├── Views/               # Razor views
├── Services/            # Business logic services
├── Data/                # Database context and migrations
├── Attributes/          # Custom attributes
├── Middleware/          # Custom middleware
├── scripts/             # Database setup scripts
└── wwwroot/            # Static files
\`\`\`

## Database Schema

### Core Tables
- **Users**: User accounts and authentication
- **Roles**: User roles (Admin, User)
- **ConferenceRooms**: Room information
- **Bookings**: Room booking records
- **Permissions**: System permissions
- **UserRoles**: User-role relationships

## License

This project is for educational/internship purposes.
\`\`\`

```csharp file="Attributes/RequirePermissionAttribute.cs"
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using ConferenceRoomBooking.Services;

namespace ConferenceRoomBooking.Attributes
{
    public class RequirePermissionAttribute : Attribute, IAuthorizationFilter
    {
        private readonly string _permission;

        public RequirePermissionAttribute(string permission)
        {
            _permission = permission;
        }

        public void OnAuthorization(AuthorizationFilterContext context)
        {
            var permissionService = context.HttpContext.RequestServices.GetService<IPermissionService>();
            var userId = context.HttpContext.Session.GetInt32("UserId");

            if (userId == null)
            {
                context.Result = new RedirectToActionResult("Login", "Account", null);
                return;
            }

            if (permissionService != null && !permissionService.HasPermission(userId.Value, _permission))
            {
                context.Result = new ViewResult
                {
                    ViewName = "AccessDenied"
                };
            }
        }
    }
}
