-- Step 4: Insert Seed Data
USE ConferenceRoomBookingDb;
GO

-- Insert Users (Admin and Regular Users)
INSERT INTO Users (Name, Email, Username, Password, IsAdmin) VALUES
('System Administrator', 'admin@company.com', 'admin', 'admin123', 1),
('John Doe', 'john.doe@company.com', 'john', 'user123', 0),
('Jane Smith', 'jane.smith@company.com', 'jane', 'user123', 0),
('Mike Johnson', 'mike.johnson@company.com', 'mike', 'user123', 0),
('Sarah Wilson', 'sarah.wilson@company.com', 'sarah', 'user123', 0);
GO

-- Insert Conference Rooms
INSERT INTO ConferenceRooms (Name, Description, Capacity, Location) VALUES
('Board Room', 'Executive meeting room with video conferencing facilities', 12, 'Floor 10, East Wing'),
('Conference Room A', 'Large conference room with presentation equipment', 20, 'Floor 5, West Wing'),
('Conference Room B', 'Medium conference room with whiteboard', 15, 'Floor 5, East Wing'),
('Meeting Room 1', 'Small meeting room for team discussions', 6, 'Floor 3, North Wing'),
('Meeting Room 2', 'Small meeting room with phone conference', 8, 'Floor 3, South Wing'),
('Training Room', 'Large training room with projector and sound system', 30, 'Floor 2, Central'),
('Innovation Lab', 'Creative space with flexible seating arrangements', 10, 'Floor 4, West Wing'),
('Client Meeting Room', 'Professional meeting room for client presentations', 8, 'Floor 1, Reception Area');
GO

-- Insert Sample Bookings (for demonstration)
DECLARE @TomorrowStart DATETIME2 = DATEADD(DAY, 1, CAST(GETDATE() AS DATE));
DECLARE @TomorrowEnd DATETIME2 = DATEADD(HOUR, 1, @TomorrowStart);

INSERT INTO Bookings (UserId, ConferenceRoomId, Title, Description, StartTime, EndTime, Status) VALUES
(2, 1, 'Weekly Team Meeting', 'Regular team sync-up meeting', 
 DATEADD(HOUR, 9, @TomorrowStart), DATEADD(HOUR, 10, @TomorrowStart), 'Confirmed'),
(3, 2, 'Project Planning Session', 'Planning for Q2 project deliverables', 
 DATEADD(HOUR, 14, @TomorrowStart), DATEADD(HOUR, 16, @TomorrowStart), 'Confirmed'),
(4, 3, 'Client Presentation', 'Presenting new features to client', 
 DATEADD(HOUR, 11, @TomorrowStart), DATEADD(HOUR, 12, @TomorrowStart), 'Confirmed'),
(5, 6, 'Training Session', 'New employee orientation training', 
 DATEADD(HOUR, 10, DATEADD(DAY, 2, @TomorrowStart)), DATEADD(HOUR, 12, DATEADD(DAY, 2, @TomorrowStart)), 'Confirmed');
GO

PRINT 'Seed data inserted successfully!';
