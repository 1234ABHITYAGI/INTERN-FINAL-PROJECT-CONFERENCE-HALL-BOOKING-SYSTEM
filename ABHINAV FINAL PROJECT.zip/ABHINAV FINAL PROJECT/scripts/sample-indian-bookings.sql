-- Insert sample bookings with Indian context
USE TestIPI;
GO

-- Clear existing sample bookings
DELETE FROM Bookings;

DECLARE @Tomorrow DATETIME2 = DATEADD(DAY, 1, CAST(GETDATE() AS DATE));
DECLARE @NextWeek DATETIME2 = DATEADD(DAY, 7, CAST(GETDATE() AS DATE));

-- Rohit's bookings (Admin)
INSERT INTO Bookings (UserId, ConferenceRoomId, Title, Description, StartTime, EndTime, Status, CreatedAt) VALUES
((SELECT Id FROM Users WHERE Username = 'rohit'), 
 (SELECT Id FROM ConferenceRooms WHERE Name = 'Ganga Conference Room'), 
 'Sprint Planning - Q4', 
 'Quarterly sprint planning for development team with stakeholders from Mumbai and Bangalore', 
 DATEADD(HOUR, 9, @Tomorrow), 
 DATEADD(HOUR, 11, @Tomorrow), 
 'Confirmed', 
 GETDATE()),

((SELECT Id FROM Users WHERE Username = 'rohit'), 
 (SELECT Id FROM ConferenceRooms WHERE Name = 'Yamuna Meeting Hall'), 
 'Client Demo - TCS', 
 'Product demonstration for TCS team', 
 DATEADD(HOUR, 14, @Tomorrow), 
 DATEADD(HOUR, 16, @Tomorrow), 
 'Confirmed', 
 GETDATE());

-- Priya's bookings (Manager)
INSERT INTO Bookings (UserId, ConferenceRoomId, Title, Description, StartTime, EndTime, Status, CreatedAt) VALUES
((SELECT Id FROM Users WHERE Username = 'priya'), 
 (SELECT Id FROM ConferenceRooms WHERE Name = 'Saraswati Discussion Room'), 
 'HR Policy Review', 
 'Review of updated HR policies for Indian operations', 
 DATEADD(HOUR, 10, @Tomorrow), 
 DATEADD(HOUR, 12, @Tomorrow), 
 'Confirmed', 
 GETDATE()),

((SELECT Id FROM Users WHERE Username = 'priya'), 
 (SELECT Id FROM ConferenceRooms WHERE Name = 'Kaveri Training Room'), 
 'New Joiner Orientation', 
 'Welcome session for new employees joining from IIT and NIT campuses', 
 DATEADD(HOUR, 9, DATEADD(DAY, 2, @Tomorrow)), 
 DATEADD(HOUR, 12, DATEADD(DAY, 2, @Tomorrow)), 
 'Confirmed', 
 GETDATE());

-- Vikram's bookings (User)
INSERT INTO Bookings (UserId, ConferenceRoomId, Title, Description, StartTime, EndTime, Status, CreatedAt) VALUES
((SELECT Id FROM Users WHERE Username = 'vikram'), 
 (SELECT Id FROM ConferenceRooms WHERE Name = 'Krishna Meeting Pod'), 
 'Daily Standup - Backend Team', 
 'Daily standup for backend development team', 
 DATEADD(HOUR, 9, @Tomorrow), 
 DATEADD(HOUR, 10, @Tomorrow), 
 'Confirmed', 
 GETDATE()),

((SELECT Id FROM Users WHERE Username = 'vikram'), 
 (SELECT Id FROM ConferenceRooms WHERE Name = 'Godavari Innovation Lab'), 
 'Code Review Session', 
 'Weekly code review and knowledge sharing session', 
 DATEADD(HOUR, 15, @Tomorrow), 
 DATEADD(HOUR, 17, @Tomorrow), 
 'Confirmed', 
 GETDATE());

-- Anita's bookings (User)
INSERT INTO Bookings (UserId, ConferenceRoomId, Title, Description, StartTime, EndTime, Status, CreatedAt) VALUES
((SELECT Id FROM Users WHERE Username = 'anita'), 
 (SELECT Id FROM ConferenceRooms WHERE Name = 'Narmada Boardroom'), 
 'Budget Planning FY24-25', 
 'Annual budget planning meeting for next financial year', 
 DATEADD(HOUR, 11, @Tomorrow), 
 DATEADD(HOUR, 13, @Tomorrow), 
 'Confirmed', 
 GETDATE());

-- Suresh's bookings (User)
INSERT INTO Bookings (UserId, ConferenceRoomId, Title, Description, StartTime, EndTime, Status, CreatedAt) VALUES
((SELECT Id FROM Users WHERE Username = 'suresh'), 
 (SELECT Id FROM ConferenceRooms WHERE Name = 'Brahmaputra Conference Hall'), 
 'All Hands Meeting', 
 'Monthly all hands meeting with updates from leadership team', 
 DATEADD(HOUR, 16, @Tomorrow), 
 DATEADD(HOUR, 18, @Tomorrow), 
 'Confirmed', 
 GETDATE());

-- Kavya's bookings (User)
INSERT INTO Bookings (UserId, ConferenceRoomId, Title, Description, StartTime, EndTime, Status, CreatedAt) VALUES
((SELECT Id FROM Users WHERE Username = 'kavya'), 
 (SELECT Id FROM ConferenceRooms WHERE Name = 'Saraswati Discussion Room'), 
 'UI/UX Design Review', 
 'Design review for mobile app interface', 
 DATEADD(HOUR, 13, @Tomorrow), 
 DATEADD(HOUR, 15, @Tomorrow), 
 'Confirmed', 
 GETDATE());

-- Arjun's bookings (User)
INSERT INTO Bookings (UserId, ConferenceRoomId, Title, Description, StartTime, EndTime, Status, CreatedAt) VALUES
((SELECT Id FROM Users WHERE Username = 'arjun'), 
 (SELECT Id FROM ConferenceRooms WHERE Name = 'Kaveri Training Room'), 
 'Technical Training - React', 
 'React.js training session for frontend team', 
 DATEADD(HOUR, 10, DATEADD(DAY, 3, @Tomorrow)), 
 DATEADD(HOUR, 12, DATEADD(DAY, 3, @Tomorrow)), 
 'Confirmed', 
 GETDATE());

-- Some cancelled bookings for variety
INSERT INTO Bookings (UserId, ConferenceRoomId, Title, Description, StartTime, EndTime, Status, CreatedAt, CancelledAt) VALUES
((SELECT Id FROM Users WHERE Username = 'deepika'), 
 (SELECT Id FROM ConferenceRooms WHERE Name = 'Ganga Conference Room'), 
 'Client Call - Infosys', 
 'Cancelled due to client rescheduling', 
 DATEADD(HOUR, 12, @Tomorrow), 
 DATEADD(HOUR, 13, @Tomorrow), 
 'Cancelled', 
 DATEADD(HOUR, -2, GETDATE()),
 DATEADD(HOUR, -1, GETDATE()));

PRINT 'Sample Indian bookings created successfully!';

-- Show booking summary
SELECT 
    u.Name as 'Booked By',
    cr.Name as 'Room',
    b.Title,
    b.StartTime,
    b.Status
FROM Bookings b
JOIN Users u ON b.UserId = u.Id
JOIN ConferenceRooms cr ON b.ConferenceRoomId = cr.Id
ORDER BY b.StartTime;
