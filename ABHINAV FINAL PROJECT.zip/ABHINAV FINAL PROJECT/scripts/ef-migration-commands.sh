# Step-by-Step Entity Framework Migration Commands

# 1. Install EF Core Tools (run in Package Manager Console or Terminal)
dotnet tool install --global dotnet-ef

# 2. Add Initial Migration
dotnet ef migrations add InitialCreate

# 3. Update Database (creates database and tables)
dotnet ef database update

# 4. Add Migration for Indexes (if needed later)
dotnet ef migrations add AddIndexes

# 5. Update Database with new migration
dotnet ef database update

# 6. View Migration History
dotnet ef migrations list

# 7. Remove Last Migration (if needed)
dotnet ef migrations remove

# 8. Generate SQL Script from Migrations
dotnet ef migrations script

# 9. Drop Database (for development)
dotnet ef database drop

# 10. Update to Specific Migration
dotnet ef database update InitialCreate
