using Microsoft.AspNetCore.Mvc;
using ConferenceRoomBooking.Data;
using ConferenceRoomBooking.Models;
using ConferenceRoomBooking.Attributes;

namespace ConferenceRoomBooking.Controllers
{
    [RequireRole("Admin")]
    public class AdminController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AdminController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var stats = new
            {
                TotalUsers = _context.Users.Count(u => u.IsActive),
                TotalRooms = _context.ConferenceRooms.Count(r => r.IsActive),
                TotalBookings = _context.Bookings.Count(),
                TodayBookings = _context.Bookings.Count(b => b.StartTime.Date == DateTime.Today)
            };

            ViewBag.Stats = stats;
            return View();
        }

        [RequirePermission("ManageRooms")]
        public IActionResult Rooms()
        {
            var rooms = _context.ConferenceRooms.Where(r => r.IsActive).ToList();
            return View(rooms);
        }

        [RequirePermission("ManageRooms")]
        [HttpGet]
        public IActionResult CreateRoom()
        {
            return View();
        }

        [RequirePermission("ManageRooms")]
        [HttpPost]
        public async Task<IActionResult> CreateRoom(ConferenceRoom room)
        {
            if (ModelState.IsValid)
            {
                room.CreatedAt = DateTime.UtcNow;
                room.UpdatedAt = DateTime.UtcNow;
                room.IsActive = true;

                _context.ConferenceRooms.Add(room);
                await _context.SaveChangesAsync();

                TempData["Success"] = "Conference room created successfully.";
                return RedirectToAction("Rooms");
            }

            return View(room);
        }

        [RequirePermission("ManageRooms")]
        [HttpGet]
        public IActionResult EditRoom(int id)
        {
            var room = _context.ConferenceRooms.Find(id);
            if (room == null || !room.IsActive)
            {
                return NotFound();
            }

            return View(room);
        }

        [RequirePermission("ManageRooms")]
        [HttpPost]
        public async Task<IActionResult> EditRoom(ConferenceRoom room)
        {
            if (ModelState.IsValid)
            {
                var existingRoom = _context.ConferenceRooms.Find(room.Id);
                if (existingRoom == null || !existingRoom.IsActive)
                {
                    return NotFound();
                }

                existingRoom.Name = room.Name;
                existingRoom.Location = room.Location;
                existingRoom.Description = room.Description;
                existingRoom.Equipment = room.Equipment;
                existingRoom.UpdatedAt = DateTime.UtcNow;

                await _context.SaveChangesAsync();

                TempData["Success"] = "Conference room updated successfully.";
                return RedirectToAction("Rooms");
            }

            return View(room);
        }

        [RequirePermission("ManageRooms")]
        [HttpPost]
        public async Task<IActionResult> DeleteRoom(int id)
        {
            var room = _context.ConferenceRooms.Find(id);
            if (room != null && room.IsActive)
            {
                room.IsActive = false;
                room.UpdatedAt = DateTime.UtcNow;
                await _context.SaveChangesAsync();

                TempData["Success"] = "Conference room deleted successfully.";
            }

            return RedirectToAction("Rooms");
        }

        [RequirePermission("ManageUsers")]
        public IActionResult UserPasswordManagement()
        {
            var users = _context.Users.Where(u => u.IsActive).ToList();
            return View(users);
        }
    }
}
