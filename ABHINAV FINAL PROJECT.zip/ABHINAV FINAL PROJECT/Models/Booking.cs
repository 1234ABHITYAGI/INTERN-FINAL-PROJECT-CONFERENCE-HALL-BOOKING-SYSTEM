using System.ComponentModel.DataAnnotations;

namespace ConferenceRoomBooking.Models
{
    public enum BookingStatus
    {
        Confirmed,
        Cancelled,
        Completed
    }
    
    public class Booking
    {
        public int Id { get; set; }
        
        [Required]
        public int UserId { get; set; }
        
        [Required]
        public int RoomId { get; set; }
        
        [Required]
        [StringLength(200)]
        public string Title { get; set; } = string.Empty;
        
        [StringLength(1000)]
        public string? Description { get; set; }
        
        [Required]
        public DateTime StartTime { get; set; }
        
        [Required]
        public DateTime EndTime { get; set; }
        
        [Required]
        [StringLength(20)]
        public string Status { get; set; } = "Confirmed";
        
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
        
        // Navigation properties
        public virtual User User { get; set; } = null!;
        public virtual ConferenceRoom Room { get; set; } = null!;
    }
}
