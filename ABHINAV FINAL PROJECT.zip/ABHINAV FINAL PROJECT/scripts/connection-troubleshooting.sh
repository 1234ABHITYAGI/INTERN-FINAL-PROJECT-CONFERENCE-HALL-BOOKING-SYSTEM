# Connection Troubleshooting Commands

# 1. Test network connectivity to SQL Server
ping 10.7.74.186

# 2. Test SQL Server port (default 1433)
telnet 10.7.74.186 1433

# 3. Test with sqlcmd (if installed)
sqlcmd -S 10.7.74.186 -U INTERN -P Intern@123 -d TestIPI -Q "SELECT @@VERSION"

# 4. Alternative connection test
sqlcmd -S 10.7.74.186 -U INTERN -P Intern@123 -Q "SELECT name FROM sys.databases"

# 5. If using Entity Framework CLI tools
dotnet ef database update --connection "Server=10.7.74.186;Database=TestIPI;User Id=INTERN;Password=Intern@123;TrustServerCertificate=true;"

# Common connection issues and solutions:
echo "Common Issues:"
echo "1. Firewall blocking port 1433"
echo "2. SQL Server not configured for remote connections"
echo "3. SQL Server Browser service not running"
echo "4. Wrong authentication mode"
echo "5. User permissions insufficient"
