using Microsoft.AspNetCore.Mvc;
using ConferenceRoomBooking.Data;
using ConferenceRoomBooking.Models;
using Microsoft.EntityFrameworkCore;

namespace ConferenceRoomBooking.Controllers
{
    public class BookingController : Controller
    {
        private readonly ApplicationDbContext _context;

        public BookingController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var userRole = HttpContext.Session.GetString("UserRole");
            IQueryable<Booking> bookingsQuery = _context.Bookings.Include(b => b.User).Include(b => b.Room);

            if (userRole != "Admin")
            {
                bookingsQuery = bookingsQuery.Where(b => b.UserId == userId.Value);
            }

            var bookings = bookingsQuery.OrderByDescending(b => b.StartTime).ToList();
            return View(bookings);
        }

        [HttpGet]
        public IActionResult Create()
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var rooms = _context.ConferenceRooms.Where(r => r.IsActive).ToList();
            ViewBag.Rooms = rooms;

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(BookingViewModel model)
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null)
            {
                return RedirectToAction("Login", "Account");
            }

            if (ModelState.IsValid)
            {
                // Check for conflicts
                var hasConflict = _context.Bookings.Any(b =>
                    b.RoomId == model.RoomId &&
                    b.Status == "Confirmed" &&
                    ((model.StartTime >= b.StartTime && model.StartTime &lt; b.EndTime) ||
                     (model.EndTime > b.StartTime && model.EndTime &lt;= b.EndTime) ||
                     (model.StartTime &lt;= b.StartTime && model.EndTime >= b.EndTime)));

                if (hasConflict)
                {
                    ModelState.AddModelError("", "The selected time slot conflicts with an existing booking.");
                    var rooms = _context.ConferenceRooms.Where(r => r.IsActive).ToList();
                    ViewBag.Rooms = rooms;
                    return View(model);
                }

                var booking = new Booking
                {
                    UserId = userId.Value,
                    RoomId = model.RoomId,
                    Title = model.Title,
                    Description = model.Description,
                    StartTime = model.StartTime,
                    EndTime = model.EndTime,
                    Status = "Confirmed",
                    CreatedAt = DateTime.UtcNow,
                    UpdatedAt = DateTime.UtcNow
                };

                _context.Bookings.Add(booking);
                await _context.SaveChangesAsync();

                TempData["Success"] = "Booking created successfully.";
                return RedirectToAction("Index");
            }

            var roomsList = _context.ConferenceRooms.Where(r => r.IsActive).ToList();
            ViewBag.Rooms = roomsList;
            return View(model);
        }

        public IActionResult Calendar()
        {
            var bookings = _context.Bookings
                .Include(b => b.Room)
                .Include(b => b.User)
                .Where(b => b.Status == "Confirmed")
                .Select(b => new
                {
                    id = b.Id,
                    title = $"{b.Title} - {b.Room.Name}",
                    start = b.StartTime.ToString("yyyy-MM-ddTHH:mm:ss"),
                    end = b.EndTime.ToString("yyyy-MM-ddTHH:mm:ss"),
                    description = b.Description,
                    room = b.Room.Name,
                    user = $"{b.User.FirstName} {b.User.LastName}"
                })
                .ToList();

            ViewBag.BookingsJson = System.Text.Json.JsonSerializer.Serialize(bookings);
            return View();
        }
    }
}
