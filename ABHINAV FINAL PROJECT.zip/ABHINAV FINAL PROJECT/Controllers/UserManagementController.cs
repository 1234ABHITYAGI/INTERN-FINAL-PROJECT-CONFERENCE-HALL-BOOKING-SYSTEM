using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ConferenceRoomBooking.Data;
using ConferenceRoomBooking.Models;
using ConferenceRoomBooking.Services;
using ConferenceRoomBooking.Attributes;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System;
using Microsoft.Extensions.Logging;

namespace ConferenceRoomBooking.Controllers
{
    [RequireRole("Admin")]
    public class UserManagementController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IPermissionService _permissionService;
        private readonly ILogger<UserManagementController> _logger;
        
        public UserManagementController(
            ApplicationDbContext context, 
            IPermissionService permissionService,
            ILogger<UserManagementController> logger)
        {
            _context = context;
            _permissionService = permissionService;
            _logger = logger;
        }
        
        [RequirePermission("ManageUsers")]
        public async Task<IActionResult> Index()
        {
            var users = await _context.Users
                .Where(u => u.IsActive)
                .Select(u => new UserManagementViewModel
                {
                    Id = u.Id,
                    Username = u.Username,
                    Email = u.Email,
                    FirstName = u.FirstName,
                    LastName = u.LastName,
                    Department = u.Department,
                    IsActive = u.IsActive,
                    CreatedAt = u.CreatedAt,
                    Role = _context.UserRoles
                        .Where(ur => ur.UserId == u.Id)
                        .Join(_context.Roles, ur => ur.RoleId, r => r.Id, (ur, r) => r.Name)
                        .FirstOrDefault() ?? "User"
                })
                .ToListAsync();

            return View(users);
        }
        
        // Create new employee user
        [HttpGet]
        public async Task<IActionResult> CreateEmployee()
        {
            var roles = await _context.Roles.Where(r => r.IsActive).ToListAsync();
            ViewBag.Roles = roles;
            return View(new CreateEmployeeViewModel());
        }
        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateEmployee(CreateEmployeeViewModel model)
        {
            if (ModelState.IsValid)
            {
                // Check if username or email already exists
                var existingUser = await _context.Users
                    .FirstOrDefaultAsync(u => u.Username == model.Username || u.Email == model.Email);
                
                if (existingUser != null)
                {
                    ModelState.AddModelError("", "Username or email already exists.");
                }
                else
                {
                    var user = new User
                    {
                        Name = model.Name,
                        Email = model.Email,
                        Username = model.Username,
                        Password = model.Password, // In production, hash this!
                        IsAdmin = false,
                        IsActive = true,
                        CreatedAt = DateTime.Now
                    };
                    
                    _context.Users.Add(user);
                    await _context.SaveChangesAsync();
                    
                    // Assign default role (User)
                    var userRole = await _context.Roles.FirstOrDefaultAsync(r => r.Name == "User");
                    if (userRole != null)
                    {
                        await _permissionService.AssignRoleToUserAsync(user.Id, userRole.Id, GetCurrentUserId().Value);
                    }
                    
                    _logger.LogInformation("New employee user created: {UserName} by admin {AdminId}", 
                        user.Name, GetCurrentUserId());
                    
                    TempData["Success"] = $"Employee {model.Name} has been added successfully!";
                    return RedirectToAction(nameof(Index));
                }
            }
            
            var roles = await _context.Roles.Where(r => r.IsActive).ToListAsync();
            ViewBag.Roles = roles;
            return View(model);
        }
        
        // Bulk import employees from CSV
        [HttpGet]
        public IActionResult BulkImport()
        {
            return View();
        }
        
        [HttpPost]
        public async Task<IActionResult> BulkImport(IFormFile csvFile)
        {
            if (csvFile == null || csvFile.Length == 0)
            {
                TempData["Error"] = "Please select a CSV file.";
                return View();
            }
            
            var results = new List<string>();
            var successCount = 0;
            var errorCount = 0;
            
            using (var reader = new StreamReader(csvFile.OpenReadStream()))
            {
                var line = await reader.ReadLineAsync(); // Skip header
                
                while ((line = await reader.ReadLineAsync()) != null)
                {
                    var values = line.Split(',');
                    
                    if (values.Length >= 4)
                    {
                        try
                        {
                            var name = values[0].Trim();
                            var email = values[1].Trim();
                            var username = values[2].Trim();
                            var department = values[3].Trim();
                            
                            // Check if user already exists
                            var existingUser = await _context.Users
                                .FirstOrDefaultAsync(u => u.Username == username || u.Email == email);
                            
                            if (existingUser == null)
                            {
                                var user = new User
                                {
                                    Name = name,
                                    Email = email,
                                    Username = username,
                                    Password = "TempPass@123", // Temporary password
                                    IsAdmin = false,
                                    IsActive = true,
                                    CreatedAt = DateTime.Now
                                };
                                
                                _context.Users.Add(user);
                                await _context.SaveChangesAsync();
                                
                                // Assign default User role
                                var userRole = await _context.Roles.FirstOrDefaultAsync(r => r.Name == "User");
                                if (userRole != null)
                                {
                                    await _permissionService.AssignRoleToUserAsync(user.Id, userRole.Id, GetCurrentUserId().Value);
                                }
                                
                                results.Add($"✅ {name} - Created successfully");
                                successCount++;
                            }
                            else
                            {
                                results.Add($"⚠️ {name} - Already exists");
                                errorCount++;
                            }
                        }
                        catch (Exception ex)
                        {
                            results.Add($"❌ Error processing line: {line} - {ex.Message}");
                            errorCount++;
                        }
                    }
                }
            }
            
            ViewBag.Results = results;
            ViewBag.SuccessCount = successCount;
            ViewBag.ErrorCount = errorCount;
            
            return View("BulkImportResults");
        }
        
        // Deactivate employee (don't delete, just deactivate)
        [HttpPost]
        public async Task<IActionResult> DeactivateEmployee(int id)
        {
            var user = await _context.Users.FindAsync(id);
            if (user != null)
            {
                user.IsActive = false;
                await _context.SaveChangesAsync();
                
                _logger.LogInformation("Employee deactivated: {UserName} by admin {AdminId}", 
                    user.Name, GetCurrentUserId());
                
                return Json(new { success = true, message = $"{user.Name} has been deactivated." });
            }
            
            return Json(new { success = false, message = "User not found." });
        }
        
        private int? GetCurrentUserId()
        {
            var userIdClaim = HttpContext.Session.GetString("UserId");
            return int.TryParse(userIdClaim, out int userId) ? userId : null;
        }
    }
}
